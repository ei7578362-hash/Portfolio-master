import type { RangeValue, RecursivePartial } from "../../Types";
import type { IAnimation } from "../Interfaces/IAnimation";
import type { IOptionLoader } from "../Interfaces/IOptionLoader";
export declare class AnimationOptions implements IAnimation, IOptionLoader<IAnimation> {
    count: RangeValue;
    enable: boolean;
    speed: RangeValue;
    sync: boolean;
    constructor();
    load(data?: RecursivePartial<IAnimation>): void;
}
