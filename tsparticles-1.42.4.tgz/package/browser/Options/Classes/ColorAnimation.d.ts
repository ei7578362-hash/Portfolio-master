import type { RangeValue, RecursivePartial } from "../../Types";
import type { IColorAnimation } from "../Interfaces/IColorAnimation";
import type { IOptionLoader } from "../Interfaces/IOptionLoader";
/**
 * @category Options
 */
export declare class ColorAnimation implements IColorAnimation, IOptionLoader<IColorAnimation> {
    count: RangeValue;
    enable: boolean;
    offset: RangeValue;
    speed: RangeValue;
    sync: boolean;
    constructor();
    load(data?: RecursivePartial<IColorAnimation>): void;
}
