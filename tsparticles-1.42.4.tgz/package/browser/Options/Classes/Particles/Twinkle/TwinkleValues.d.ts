import type { RangeValue, RecursivePartial } from "../../../../Types";
import type { IOptionLoader } from "../../../Interfaces/IOptionLoader";
import type { ITwinkleValues } from "../../../Interfaces/Particles/Twinkle/ITwinkleValues";
import { OptionsColor } from "../../OptionsColor";
/**
 * @category Options
 */
export declare class TwinkleValues implements ITwinkleValues, IOptionLoader<ITwinkleValues> {
    color?: OptionsColor;
    enable: boolean;
    frequency: number;
    opacity: RangeValue;
    constructor();
    load(data?: RecursivePartial<ITwinkleValues>): void;
}
