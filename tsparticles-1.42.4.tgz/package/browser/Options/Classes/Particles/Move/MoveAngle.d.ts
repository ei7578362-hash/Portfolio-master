import type { RangeValue, RecursivePartial } from "../../../../Types";
import type { IMoveAngle } from "../../../Interfaces/Particles/Move/IMoveAngle";
import type { IOptionLoader } from "../../../Interfaces/IOptionLoader";
/**
 * @category Options
 */
export declare class MoveAngle implements IMoveAngle, IOptionLoader<IMoveAngle> {
    offset: RangeValue;
    value: RangeValue;
    constructor();
    load(data?: RecursivePartial<IMoveAngle>): void;
}
