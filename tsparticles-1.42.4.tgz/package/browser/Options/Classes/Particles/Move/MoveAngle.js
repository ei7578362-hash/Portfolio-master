import { setRangeValue } from "../../../../Utils";
/**
 * @category Options
 */
export class MoveAngle {
    constructor() {
        this.offset = 0; //45;
        this.value = 90;
    }
    load(data) {
        if (data === undefined) {
            return;
        }
        if (data.offset !== undefined) {
            this.offset = setRangeValue(data.offset);
        }
        if (data.value !== undefined) {
            this.value = setRangeValue(data.value);
        }
    }
}
