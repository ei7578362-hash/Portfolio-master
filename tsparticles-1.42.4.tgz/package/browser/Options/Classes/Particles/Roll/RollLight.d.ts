import type { RangeValue, RecursivePartial } from "../../../../Types";
import type { IOptionLoader } from "../../../Interfaces/IOptionLoader";
import type { IRollLight } from "../../../Interfaces/Particles/Roll/IRollLight";
export declare class RollLight implements IRollLight, IOptionLoader<IRollLight> {
    enable: boolean;
    value: RangeValue;
    constructor();
    load(data?: RecursivePartial<IRollLight>): void;
}
