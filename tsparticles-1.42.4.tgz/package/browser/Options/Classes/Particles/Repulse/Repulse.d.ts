import type { RangeValue, RecursivePartial } from "../../../../Types";
import type { IOptionLoader } from "../../../Interfaces/IOptionLoader";
import type { IRepulse } from "../../../Interfaces/Particles/Repulse/IRepulse";
import { ValueWithRandom } from "../../ValueWithRandom";
/**
 * @category Options
 */
export declare class Repulse extends ValueWithRandom implements IRepulse, IOptionLoader<IRepulse> {
    enabled: boolean;
    distance: RangeValue;
    duration: RangeValue;
    factor: RangeValue;
    speed: RangeValue;
    constructor();
    load(data?: RecursivePartial<IRepulse>): void;
}
