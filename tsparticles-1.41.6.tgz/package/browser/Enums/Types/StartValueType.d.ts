/**
 * @category Enums
 */
export declare const enum StartValueType {
    max = "max",
    min = "min",
    random = "random"
}
