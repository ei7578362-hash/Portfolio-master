/**
 * @category Enums
 */
export declare const enum DestroyType {
    none = "none",
    max = "max",
    min = "min"
}
